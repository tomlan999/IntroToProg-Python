
#-------------------------------------------------#
# Title: mod05-homework
# Dev:   Tom Landeis
# Date:  October 30, 2016
# Desc: Create, update and store a to do list
# ChangeLog:
#-------------------------------------------------#
'''

This time, you will create a new script that manages a "ToDo list." The ToDo file will contain two columns of data
(Task, Priority) which you will store in a Python dictionary. Each Dictionary will represent one row of data.
Which will then be added to a Python List to create a table of data.

1.	Create a text file called Todo.txt using the following data:

Clean House,low

Pay Bills,high

2.	When the program starts, load each row of data from the ToDo.txt text file into a Python dictionary.

Tip: You can use a for loop to read a single line of text from the file and then place the data into a new dictionary object.

3.	After you get a row of data stored in a Python dictionary, add the new “row” into a Python List object
(now the data will be managed as a table or two-dimensional array).

4.	Display the contents of the List to the user.

5.	Allow the user to Add or Remove tasks from the list using numbered choices. Something like this would work:

    print ("Choose 1 to Add task")
    print ("Choose 2 to Remove task")
    print ("Choose 3 to Save all tasks to the Todo.txt file and exit!")

6.	Save the data from the table into the Todo.txt file when the program exits.

Open file
Read each line and add as dictionary item to todo list
print the list
Ask user to add, remove or save
Add to list
Remove from list
Save list to txt file
'''

# Declare variables
toDoList = []
userSelection = 0

# Open the file, create a to do list, close the file
#============================================================================================

todo = open("C:\\Users\\n0180155\\Desktop\\Module05\\ToDo.txt", "r")

for line in todo:
    line = line.strip("\n") # Strip the newline characters
    items = line.split(",") # Split the string into a list at the comma
    task, priority = items # Extract the two strings
    row = {task : priority} # Create a dictionary to add to the toDoList list
    toDoList.append(row) # Add the dictionary to the list

todo.close()

# Display current to do list
#============================================================================================

print ("You have a lot to do today.  Better get crackin!!\n")

def display():  # Use a function to display the to do list so it can be reused
    header =  ("Task\tPriority")
    header = header.expandtabs(20) # Expandtabs method puts tabs in specific positions for column alignment
    print (header)
    for row in toDoList:
        for task, priority in row.items(): # Items method returns key/value pairs in form of a tuple
            displayTask = (task + "\t" + priority)
            displayTask = displayTask.expandtabs(20) # Create a row to display and use expandtabs to align the columns
            print (displayTask)
display()

# Allow the user to update the to do list
#============================================================================================

while True: # While the user has not entered 3
    print ("\nChoose 1 to Add a task")
    print ("Choose 2 to Remove a task")
    print ("Choose 3 to Save all tasks to the Todo.txt file and exit!\n")
    userSelection = input()

    if userSelection == "1": # If user enters 1, add the task
        exists = "n"
        task = input("Please enter a new todo item: ")
        for row in toDoList: # Check all rows to see if the task already exists
            for key in row: # The in operator checks for keys in a dictionary
                keytest = row.keys() # Retrieve the key
                keystring = "".join(keytest) # Convert to a string
                if task.lower() == keystring.lower():
                    exists = "y"
        if exists == "n": # If the task does not exist, add it to the list and display the new list
            priority = input("Please enter a priority for this task - low, med or high: \n")
            if priority.lower() == "low" or priority.lower() == "med" or priority.lower() == "high":  # Check to see if priority properly formatted
                newRow = {task: priority}  # Create a dictionary to add to the toDoList list
                toDoList.append(newRow)  # Add the dictionary to the list
                print ("Here is your updated to do list!!\n")
                display()
            else:
                print("Priority must be low, med or high.\n")
        else:
            print ("That task already exists!!\n")

    elif userSelection == "2": # If user enters 2, remove the task
        remove = input("Please enter the item to be removed: ")
        found = "n"
        for row in toDoList: # Check all rows for the task
            for key in row:
                keytest = row.keys()  # Retrieve the key
                keystring = "".join(keytest)  # Convert to a string
                if remove.lower() == keystring.lower(): # Remove the task if it is found
                    toDoList.remove(row)
                    found = "y"
                    print("Here is your updated to do list!!\n")
                    display()
        if found == "n":
            print ("That task is not on your to do list!")
    elif userSelection == '3':
        break
    else:
        print ("You must enter 1, 2 or 3!")

# Retrieve each dictionary as a tuple, unpack into task and priority, write to file
#============================================================================================

todo = open("C:\\Users\\n0180155\\Desktop\\Module05\\ToDo.txt", "w")

for row in toDoList:
    for (task, priority) in row.items():
        line = (task + "," + priority + "\n")
        todo.write(line)
todo.close()

print ("Your to do list has been saved to a file!!")
